# data_loader.py
import pandas as pd

# Global DataFrame
df = None

def load_data(file_path):
    global df
    df = pd.read_csv(file_path)
    df.columns = df.columns.str.strip().str.lower()  # Normalize column names
    print("Data loaded and cleaned successfully.\n")
    return df
