# road_display file

def display_available_roads(df):
    print("Available Roads and Their Areas:\n")
    unique_roads = df[['area name', 'road/intersection name']].drop_duplicates()# multiple roads in the same area
    print(unique_roads.to_string(index=False))
